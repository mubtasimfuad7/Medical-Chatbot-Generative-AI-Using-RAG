"""
Bot information and related functionality.
"""

import random
from utils.pattern_matching import BOT_KEYWORDS

# Bot identity information
BOT_INFO = {
    "name": "Local RAG Chatbot",
    "version": "1.0",
    "description": "An advanced healthcare assistant providing accurate medical information and pricing.",
    "capabilities": [
        "Answering medical questions based on verified information",
        "Providing treatment pricing information",
        "Offering general healthcare guidance",
        "Responding with natural conversational patterns"
    ],
    "limitations": [
        "Cannot provide personalized medical diagnosis",
        "Information is limited to the available knowledge database",
        "Not a replacement for professional medical consultation"
    ]
}

def is_about_bot(question: str) -> bool:
    """Detect if the question is asking about the bot itself."""
    question_lower = question.lower()
    return any(keyword in question_lower for keyword in BOT_KEYWORDS)

def get_bot_response(query: str = None) -> str:
    """Generate a professional response about the bot with human-like variations."""
    variants = [
        f"I'm {BOT_INFO['name']}, a healthcare information assistant designed to provide evidence-based medical information and pricing details. While I offer general healthcare guidance, I'm not a substitute for professional medical advice.",
        
        f"I'm {BOT_INFO['name']}, an AI healthcare assistant that provides medical information and pricing details from verified sources. I can help with general healthcare questions, but remember that I'm not a replacement for consulting with a healthcare professional.",
        
        f"My name is {BOT_INFO['name']}, and I'm here to assist you with healthcare information and pricing inquiries. I draw from a database of verified medical knowledge, though I should mention that my responses aren't a substitute for professional medical consultation."
    ]
    
    return random.choice(variants)