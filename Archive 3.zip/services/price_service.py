"""
Price extraction and handling services.
"""
import random
import functools
from models import vector_store_test
from utils import (
    normalize_treatment_name,
    treatments_match,
    extract_price_from_text,
    treatment_cache,
    vector_search_cache,
    RESPONSE_VARIATIONS
)

@functools.lru_cache(maxsize=1)
def create_price_prompt_template():
    """Create a template for price prompts (cached)"""
    return """You are Local RAG Chatbot, a professional medical pricing assistant. Use ONLY the provided context to answer the question.
If the pricing information is not in the context, say "I don't have pricing information about that in my database."

IMPORTANT: Your response must be 3-5 sentences total. Be concise, direct, and conversational.
Use natural language with slight variations in sentence structure. Avoid repetitive patterns.
Do not use hashtag symbols (#) in your responses.
When mentioning prices, always use the format: X.00 BDT.

Context:
{context}

Question: {question}

Response (3-5 sentences only, maintain professional but conversational tone):"""

def create_price_prompt(context, question):
    """Create a specialized prompt for price inquiries"""
    template = create_price_prompt_template()
    return template.format(context=context, question=question)

def process_direct_price_query(treatment_query):
    """Process queries that are direct price lookups"""
    # Check cache first
    cache_key = f"price_{normalize_treatment_name(treatment_query)}"
    if cache_key in treatment_cache:
        return treatment_cache[cache_key]
    
    # Use test index for treatment cost lookup with a higher k value
    search_key = f"search_{normalize_treatment_name(treatment_query)}"
    if search_key in vector_search_cache:
        docs_with_scores = vector_search_cache[search_key]
    else:
        docs_with_scores = vector_store_test.similarity_search_with_score(treatment_query, k=20)
        vector_search_cache[search_key] = docs_with_scores
    
    # First attempt: Find match using our custom matching function
    for doc, score in docs_with_scores:
        treatment, price = extract_price_from_text(doc.page_content)
        if treatment and treatments_match(treatment_query, treatment):
            response = f"The cost for {treatment_query.title()} is {price}.00 BDT. This is based on our current healthcare provider data. Remember that prices may vary slightly depending on the facility and any additional services required."
            treatment_cache[cache_key] = response
            return response
    
    # Second attempt: Extract any treatment name that looks like our query
    potential_matches = []
    for doc, score in docs_with_scores:
        treatment, price = extract_price_from_text(doc.page_content)
        if treatment and treatments_match(treatment_query, treatment):
            potential_matches.append((treatment, price, score))
    
    # If we found potential matches, use the one with highest score
    if potential_matches:
        # Sort by score (lower is better)
        potential_matches.sort(key=lambda x: x[2])
        best_match = potential_matches[0]
        response = f"The cost for {treatment_query.title()} is {best_match[1]}.00 BDT. This pricing information is based on our current database. Please note that actual costs may vary depending on specific circumstances and the healthcare facility."
        treatment_cache[cache_key] = response
        return response
    
    # Third attempt: Look for price information in the text directly
    from utils.pattern_matching import GENERAL_PRICE_PATTERN
    
    for doc, score in docs_with_scores:
        if treatment_query.lower() in doc.page_content.lower():
            # Try to extract price using a more general pattern
            price_match = GENERAL_PRICE_PATTERN.search(doc.page_content)
            if price_match:
                price = price_match.group(1)
                response = f"The cost for {treatment_query.title()} is {price}.00 BDT. This information is based on our records, but I'd recommend confirming with the healthcare provider for the most current pricing."
                treatment_cache[cache_key] = response
                return response
    
    response = random.choice(RESPONSE_VARIATIONS["pricing_unknown"])
    treatment_cache[cache_key] = response
    return response